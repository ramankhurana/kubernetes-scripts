# IoT-streaming

To run the system, simply run `docker compose up --build`
