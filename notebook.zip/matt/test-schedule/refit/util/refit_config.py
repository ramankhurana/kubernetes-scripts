import os


class RefitConfig():
    def __init__(self):
        self.minio_host = 'refit-minio:9000'
        self.minio_access_key = os.environ['MINIO_ACCESS_KEY']
        self.minio_secret_key = os.environ['MINIO_SECRET_KEY']
        self.minio_bucket_import = 'refit-import'
        self.minio_bucket_models = 'refit-models'
        self.minio_bucket_schema = 'refit-schema'
        self.integrations_host = 'refit-integrations'


