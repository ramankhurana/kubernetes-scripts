from refit import Refit
import pandas as pd
import datetime
import time

from random import randrange

project_guid = "34e107ff-732d-4154-a3e6-1bf72106d5aa"
refit = Refit(project_guid)


for i in range(1, 120): 
    n = 1000
    idx = [x for x in range(n)]

    start = datetime.datetime.now() +  datetime.timedelta(0,n * -1)

    static_data = {'Auto-Increment': idx, 
                       'DeviceID': [ 'device-xxxx' for x in idx ] , 
                       'Timestamp': [ start + datetime.timedelta(0, x) for x in idx ], 
                       'Temperature': [ randrange(80) + 20 for x in idx], 
                       'Battery': [randrange(100) for x in idx]
                      }
    df = pd.DataFrame(data = static_data)
    time.sleep(5) 
    refit.import_data(df)


print("im done")


