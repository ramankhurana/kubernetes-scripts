from enum import Enum


class SerializationFormat(Enum):
    ONNX = 1
    PMML = 2
